// Generate resource.schema.json (JSON Schema) from the Zod definition, for editor
// autocomplete/validation. Runs from tsup's `onSuccess`, so it imports the freshly
// built ESM in ./dist. Writes two copies:
//   - dist/resource.schema.json          → shipped in the npm package (files: ["dist"])
//   - src/lib/resource/resource.schema.json → committed copy, guarded by a CI drift check
//
// Generate from ResourceJsonShape (the z.object), NOT ResourceJsonSchema (which has a
// .transform() that z.toJSONSchema rejects). The input shape is what a file author writes.
import { z } from 'zod';
import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';

import { CURRENT_RESOURCE_VERSION, ResourceJsonShape } from '../dist/index.js';

const here = dirname(fileURLToPath(import.meta.url));
const pkgRoot = join(here, '..');

// `io: 'input'` represents the *input* side of any nested pipe/transform (what a file author
// writes), and `unrepresentable: 'any'` degrades anything still not expressible to `{}` (loose,
// but fine for autocomplete) instead of throwing.
const schema = z.toJSONSchema(ResourceJsonShape, {
  target: 'draft-7',
  io: 'input',
  unrepresentable: 'any',
});
schema.$id = `https://ghentcdh.github.io/crouton/schema/v${CURRENT_RESOURCE_VERSION}/resource.schema.json`;
schema.title = 'Crouton resource.json';
schema.description = `Generated from ResourceJsonShape (crouton-core). Do not edit by hand. schemaVersion ${CURRENT_RESOURCE_VERSION}.`;

const out = `${JSON.stringify(schema, null, 2)}\n`;

const distDir = join(pkgRoot, 'dist');
const committedDir = join(pkgRoot, 'src', 'lib', 'resource');
mkdirSync(distDir, { recursive: true });
mkdirSync(committedDir, { recursive: true });
writeFileSync(join(distDir, 'resource.schema.json'), out);
writeFileSync(join(committedDir, 'resource.schema.json'), out);

console.info(
  `[crouton-core] wrote resource.schema.json (v${CURRENT_RESOURCE_VERSION})`,
);
